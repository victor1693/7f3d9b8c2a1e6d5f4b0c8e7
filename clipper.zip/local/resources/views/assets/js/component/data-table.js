// BASIC DATATABLE
$("#datatable-basic").DataTable({
  language: {
    searchPlaceholder: "Search...",
    sSearch: "",
  },
  pageLength: 10,
  // scrollX: true
});
