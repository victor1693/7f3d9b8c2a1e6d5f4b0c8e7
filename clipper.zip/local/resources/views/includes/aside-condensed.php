<div class="align-middle" style="position: fixed;height: 100%;margin-left: -58px;top: 0px;width: 25px;padding-top: 15px; display: grid;place-items: center; height: 100vh;">
    <div>
        <div style="position: absolute;top: 30px;">
            <svg data-fui-icon="true" fill="none" height="32" viewbox="0 0 32 32" width="32" xmlns="http://www.w3.org/2000/svg">
                <path d="M6.45144 8.82585C4.61127 8.82585 3.34274 9.63329 2.38277 10.5464 2.38277 10.5464 1.99515 10.9137 2.00005 10.9249L6.03163 14.9565 10.0625 10.9249C9.29915 9.87398 7.8599 8.82585 6.45144 8.82585zM16.4066 8.82585C14.5664 8.82585 13.2979 9.63329 12.3379 10.5464 12.3379 10.5464 11.9839 10.9039 11.9678 10.9249L6.98462 15.9088 11.0099 19.934 20.0176 10.9249C19.2543 9.87398 17.8157 8.82585 16.4066 8.82585zM26.3889 8.82585C24.5487 8.82585 23.2802 9.63329 22.3202 10.5464 22.3202 10.5464 21.9515 10.9067 21.9375 10.9249L11.9691 20.8947 13.0242 21.9498C14.6566 23.5822 17.3287 23.5822 18.9611 21.9498L29.9874 10.9249H30C29.2366 9.87398 27.7981 8.82585 26.3889 8.82585z" fill="currentColor">
                </path>
            </svg>
        </div>
        <a class="btn btn-bitbucket w-100 btn-icon bg-dark mb-2" href="<?= Request::root();?>/home" style="width: 50px">
            <svg class="icon icon-tabler icons-tabler-outline icon-tabler-home" fill="none" height="24" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewbox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
                <path d="M0 0h24v24H0z" fill="none" stroke="none">
                </path>
                <path d="M5 12l-2 0l9 -9l9 9l-2 0">
                </path>
                <path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7">
                </path>
                <path d="M9 21v-6a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v6">
                </path>
            </svg>
        </a>
        <a class="btn btn-bitbucket w-100 btn-icon bg-dark mb-2" href="#" style="width: 50px">
            <svg class="icon icon-tabler icons-tabler-outline icon-tabler-message" fill="none" height="24" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewbox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
                <path d="M0 0h24v24H0z" fill="none" stroke="none">
                </path>
                <path d="M8 9h8">
                </path>
                <path d="M8 13h6">
                </path>
                <path d="M18 4a3 3 0 0 1 3 3v8a3 3 0 0 1 -3 3h-5l-5 3v-3h-2a3 3 0 0 1 -3 -3v-8a3 3 0 0 1 3 -3h12z">
                </path>
            </svg>
        </a>
        <a class="btn btn-bitbucket w-100 btn-icon bg-dark mb-2" href="#" style="width: 50px">
            <svg class="icon icon-tabler icons-tabler-outline icon-tabler-bell" fill="none" height="24" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewbox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
                <path d="M0 0h24v24H0z" fill="none" stroke="none">
                </path>
                <path d="M10 5a2 2 0 1 1 4 0a7 7 0 0 1 4 6v3a4 4 0 0 0 2 3h-16a4 4 0 0 0 2 -3v-3a7 7 0 0 1 4 -6">
                </path>
                <path d="M9 17v1a3 3 0 0 0 6 0v-1">
                </path>
            </svg>
        </a>
        <a class="btn btn-bitbucket w-100 btn-icon bg-dark mb-2" href="<?= Request::root();?>/profile" style="width: 50px">
            <svg class="icon icon-tabler icons-tabler-outline icon-tabler-user" fill="none" height="24" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewbox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
                <path d="M0 0h24v24H0z" fill="none" stroke="none">
                </path>
                <path d="M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0">
                </path>
                <path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2">
                </path>
            </svg>
        </a>
    </div>
</div>